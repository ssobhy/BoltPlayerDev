//
//  BPRBoltPlayerPlugin.h
//  BoltPlayerPlugin
//
//  Created by Inmobly on 12/6/16.
//  Copyright © 2016 Inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BoltPlay/IBPBoltPlay.h>
#import "IBPRBoltPlayer.h"
#import "IBPMediaItem.h"

@protocol IBPRBoltPlayerPluginDelegate <NSObject>
@optional
- (NSInteger)boltPlayerPluginAskAboutNextItemIndex:(NSInteger)currentItemIndex;
- (void)boltPlayerPluginSuggestPlayNextItem:(NSInteger)itemIndex;
- (void)boltPlayerPluginWillStartPlayNextIem;
@end

@class IBPRBoltPlayerPluginBuilder;

@interface IBPRBoltPlayerPlugin : NSObject {
    __weak id<IBPRBoltPlayerPluginDelegate> delegate;
}

+ (IBPEventEmitter*)eventEmitter;
+(instancetype)boltPlayerPluginWithBlock:(void (^)(IBPRBoltPlayerPluginBuilder *))updateBlock;
-(void) play;
-(void) play:(NSInteger)itemIndex;
-(void) playNextVideo:(NSInteger)nextItemIndex;
-(void) skipDelayPlayingNextVideo:(NSInteger)nextItemIndex;
-(void) reportFinished:(float)watchedPercent bufferedPercent:(float)bufferedPercent;
-(void) fetchPsshDataFileURL:(NSURL *)fileURL;
- (void)setDelegate:(id<IBPRBoltPlayerPluginDelegate> )newDelegate;
@end



@interface IBPRBoltPlayerPluginBuilder : NSObject

@property(nonatomic) NSString *contentId;
@property(nonatomic) NSString *file;
@property(nonatomic) NSString *adUrl;
@property(nonatomic) IBPContentType contentType;
@property(nonatomic) NSString *title;
@property(nonatomic) NSString *desc;
@property(nonatomic) NSInteger duration;
@property(nonatomic) NSArray<NSString *> *keywords;
@property(nonatomic) NSString *drmLicenseUrl;
@property(nonatomic) NSDictionary<NSString*,NSString*> *drmLicenseRequestProperties;
@property(nonatomic) NSArray<IBPMediaItem *> *mediaItemsArray;

//Player Fields
@property(nonatomic) IBPRBoltPlayer* playerView;
@property(nonatomic,weak) id<IBPRBoltPlayerViewDelegate> playerViewDelegate;



@end
