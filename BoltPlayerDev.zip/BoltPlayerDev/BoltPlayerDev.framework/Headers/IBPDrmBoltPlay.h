#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@protocol IBPUrlReadyDelegate;

typedef enum : NSUInteger {
    IBP_DRM_BOLT_PLAY_CONTENT_TYPE_SINGLE_FILE = 0,
    IBP_DRM_BOLT_PLAY_CONTENT_TYPE_WIDEVINE = 1,
    IBP_DRM_BOLT_PLAY_CONTENT_TYPE_HLS = 2,
    IBP_DRM_BOLT_PLAY_CONTENT_TYPE_UNKNOWN = -2,
} IBPDrmBoltPlayContentType;

@interface IBPDrmBoltPlay : NSObject

@property (nonatomic,weak) id<IBPUrlReadyDelegate> urlReadyDelegate;
@property (nonatomic) void(^playerReportingBlock)(NSInteger watchedPercent,NSInteger bufferedPercent);


-(void)prepareWithVideoId:(NSString *)videoId
                 videoUrl:(NSString *)videoUrl
              contentType:(IBPDrmBoltPlayContentType)boltplayContentType;

- (void)prepareWithVideoId:(NSString *)videoId
                  videoUrl:(NSString *)videoUrl
               contentType:(IBPDrmBoltPlayContentType)boltplayContentType
                licenseUrl:(NSString *)licenseUrl
        licenseRequestInfo:(NSDictionary *)licenseRequestInfo;

- (void) stop;
@end

@protocol IBPUrlReadyDelegate <NSObject>
- (void)videoReadyWithAsset:(AVURLAsset *)asset;
- (void)videoPlayError:(NSString *)error;
@end
