//
//  BoltPlayerPlugin.h
//  BoltPlayerPlugin
//
//  Created by Inmobly on 12/6/16.
//  Copyright © 2016 Inmobly. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BoltPlayerPlugin.
FOUNDATION_EXPORT double BoltPlayerPluginVersionNumber;

//! Project version string for BoltPlayerPlugin.
FOUNDATION_EXPORT const unsigned char BoltPlayerPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BoltPlayerPlugin/PublicHeader.h>

#import <BoltPlayerDev/IBPRBoltPlayerControlsView.h>
#import <BoltPlayerDev/IBPRBoltPlayer.h>
#import <BoltPlayerDev/IBPDrmBoltPlayPlugin.h>
#import <BoltPlayerDev/IBPDrmBoltPlay.h>
#import <BoltPlayerDev/IBPRBoltPlayerPlugin.h>
