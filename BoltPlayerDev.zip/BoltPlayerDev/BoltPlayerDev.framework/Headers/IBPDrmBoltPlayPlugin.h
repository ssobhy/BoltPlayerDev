//
//  BPRBoltPlayerPlugin.h
//  BoltPlayerPlugin
//
//  Created by Inmobly on 12/6/16.
//  Copyright © 2016 Inmobly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BoltPlay/IBPBoltPlay.h>
#import "IBPDrmBoltPlay.h"



@class IBPDrmBoltPlayPluginBuilder;

@interface IBPDrmBoltPlayPlugin : NSObject

+(instancetype)boltPlayerPluginWithBlock:(void (^)(IBPDrmBoltPlayPluginBuilder *))updateBlock;

-(void) load;
-(void) reportFinished:(float)watchedPercent bufferedPercent:(float)bufferedPercent;
    
+ (IBPEventEmitter*)eventEmitter;
@end



@interface IBPDrmBoltPlayPluginBuilder : NSObject

@property(nonatomic) IBPDrmBoltPlay *drmBoltPlay;
@property(nonatomic) NSString *contentId;
@property(nonatomic) NSString *file;
@property(nonatomic) IBPContentType contentType;
@property(nonatomic) NSString *title;
@property(nonatomic) NSString *desc;
@property(nonatomic) NSInteger duration;
@property(nonatomic) NSArray<NSString *> *keywords;

@property(nonatomic) NSString *drmLicenseUrl;
@property(nonatomic) NSDictionary<NSString*,NSString*> *drmLicenseRequestProperties;

@property(nonatomic) id<IBPUrlReadyDelegate> urlReadyDelegate;
    
@end
